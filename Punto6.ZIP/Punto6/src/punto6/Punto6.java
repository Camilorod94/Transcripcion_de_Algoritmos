/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto6;

import java.util.Scanner;

/**
 *
 * @author Kmilo
 */
public class Punto6 {

   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese una temperatura en grados Celsius
        System.out.print("Ingresa una temperatura en grados Celsius: ");
        int celsius = scanner.nextInt(); // Leer la temperatura desde la entrada estándar

        // Convertir de Celsius a Fahrenheit
        int fahrenheit = (celsius * 9 / 5) + 32;

        // Mostrar el resultado en la consola
        System.out.println(celsius + " grados Celsius son equivalentes a " + fahrenheit + " grados Fahrenheit.");

        // Cerrar el objeto Scanner para liberar recursos
        scanner.close();
    }
}
