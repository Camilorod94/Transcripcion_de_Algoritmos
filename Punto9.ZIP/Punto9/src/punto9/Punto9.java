/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto9;

/**
 *
 * @author Kmilo
 */
import java.util.Scanner;
import java.util.Arrays;

public class Punto9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese la cantidad de números
        System.out.print("Ingresa la cantidad de números: ");
        int cantidad = scanner.nextInt(); // Leer la cantidad desde la entrada estándar

        int[] numeros = new int[cantidad];

        // Solicitar al usuario que ingrese los números
        for (int i = 0; i < cantidad; i++) {
            System.out.print("Ingresa el número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        // Ordenar el arreglo de manera ascendente
        Arrays.sort(numeros);

        // Mostrar el arreglo ordenado
        System.out.println("Los números ordenados de manera ascendente son:");
        for (int numero : numeros) {
            System.out.print(numero + " ");
        }
    }
}

