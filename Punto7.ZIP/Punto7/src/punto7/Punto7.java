/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto7;

import java.util.Scanner;

/**
 *
 * @author Kmilo
 */
public class Punto7 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario su peso en kilogramos
        System.out.print("Ingresa tu peso en kilogramos: ");
        int peso = scanner.nextInt(); // Leer el peso desde la entrada estándar

        // Solicitar al usuario su estatura en metros
        System.out.print("Ingresa tu estatura en metros: ");
        double estatura = scanner.nextDouble(); // Leer la estatura desde la entrada estándar

        // Calcular el IMC (Índice de Masa Corporal)
        double imc = peso / (estatura * estatura);

        // Se imprime en pantalla
        System.out.println("Tu IMC es: " + imc);
    }
}
