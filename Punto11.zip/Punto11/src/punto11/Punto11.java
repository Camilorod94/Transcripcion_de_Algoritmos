/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto11;

/**
 *
 * @author kmilo
 */
import java.util.Scanner;

public class Punto11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese un número
        System.out.print("Ingresa un número para mostrar los primeros N términos de la serie de Fibonacci: ");
        int n = scanner.nextInt(); // Leer N desde la entrada estándar

        System.out.println("Los primeros " + n + " términos de la serie de Fibonacci son:");
        
        for (int i = 0; i < n; i++) {
            int fibonacci = calcularFibonacci(i);
            System.out.print(fibonacci + " ");
        }
    }

    // Función para calcular el término N de la serie de Fibonacci
    public static int calcularFibonacci(int n) {
        if (n <= 1) {
            return n;
        }
        int fibo1 = 0, fibo2 = 1, fibonacci = 0;
        for (int i = 2; i <= n; i++) {
            fibonacci = fibo1 + fibo2;
            fibo1 = fibo2;
            fibo2 = fibonacci;
        }
        return fibonacci;
    }
}
