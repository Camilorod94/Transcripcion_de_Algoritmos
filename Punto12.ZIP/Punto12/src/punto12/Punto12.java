/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto12;

/**
 *
 * @author USUARIO
 */
import java.util.Scanner;

public class Punto12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese la base
        System.out.print("Ingresa la base: ");
        int base = scanner.nextInt(); // Leer la base desde la entrada estándar

        // Solicitar al usuario que ingrese el exponente
        System.out.print("Ingresa el exponente: ");
        int exponente = scanner.nextInt(); // Leer el exponente desde la entrada estándar

        // Calcular la potencia
        int resultado = calcularPotencia(base, exponente);

        // Mostrar el resultado en la consola
        System.out.println(base + " elevado a " + exponente + " es: " + resultado);
    }

    // Función para calcular la potencia
    public static int calcularPotencia(int base, int exponente) {
        int resultado = 1;
        for (int i = 1; i <= exponente; i++) {
            resultado *= base;
        }
        return resultado;
    }
}

