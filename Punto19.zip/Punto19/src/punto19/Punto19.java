/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto19;

/**
 *
 * @author Kmilo
 */
import java.util.Scanner;

public class Punto19 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese un número decimal
        System.out.print("Ingresa un número decimal: ");
        int decimal = scanner.nextInt(); // Leer el número decimal 

        // Convertir el número decimal a su representación binaria
        String binario = convertirDecimalABinario(decimal);

        // Imprime en pantalla
        System.out.println("El número binario equivalente es: " + binario);
    }

    // Función para convertir un número decimal a su representación binaria
    public static String convertirDecimalABinario(int decimal) {
        if (decimal == 0) {
            return "0"; // Caso especial para el número decimal 0
        }
        
        StringBuilder binario = new StringBuilder();
        
        while (decimal > 0) {
            int residuo = decimal % 2;
            binario.insert(0, residuo);
            decimal /= 2;
        }

        return binario.toString();
    }
}

