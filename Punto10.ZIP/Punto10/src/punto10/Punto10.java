/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto10;

/**
 *
 * @author USUARIO
 */
import java.util.Scanner;

public class Punto10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese dos números enteros
        System.out.print("Ingresa el primer número entero: ");
        int num1 = scanner.nextInt(); // Leer el primer número desde la entrada estándar

        System.out.print("Ingresa el segundo número entero: ");
        int num2 = scanner.nextInt(); // Leer el segundo número desde la entrada estándar

        // Calcular el MCD utilizando el algoritmo de Euclides
        int mcd = calcularMCD(num1, num2);

        // Mostrar el resultado en la consola
        System.out.println("El MCD de " + num1 + " y " + num2 + " es: " + mcd);
    }

    // Función para calcular el MCD utilizando el algoritmo de Euclides
    public static int calcularMCD(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}
