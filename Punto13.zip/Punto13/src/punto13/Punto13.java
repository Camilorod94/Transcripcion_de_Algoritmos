/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto13;

/**
 *
 * @author Kmilo
 */
import java.util.Scanner;

public class Punto13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese un número entero
        System.out.print("Ingresa un número entero: ");
        int numero = scanner.nextInt(); // Leer el número desde la entrada estándar

        // Calcular el inverso del número
        int inverso = calcularInverso(numero);

        // Mostrar el resultado en la consola
        System.out.println("El inverso de " + numero + " es: " + inverso);
    }

    // Función para calcular el inverso de un número
    public static int calcularInverso(int num) {
        int inverso = 0;
        while (num != 0) {
            int digito = num % 10;
            inverso = inverso * 10 + digito;
            num = num / 10;
        }
        return inverso;
    }
}

